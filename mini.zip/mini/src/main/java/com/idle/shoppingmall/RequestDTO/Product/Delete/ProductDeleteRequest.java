package com.idle.shoppingmall.RequestDTO.Product.Delete;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Getter
@NoArgsConstructor
public class ProductDeleteRequest {
    private Long product_id;
}
