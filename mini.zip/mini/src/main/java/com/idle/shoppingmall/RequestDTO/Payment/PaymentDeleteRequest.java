package com.idle.shoppingmall.RequestDTO.Payment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Getter
@NoArgsConstructor
public class PaymentDeleteRequest {
    private Long payment_id;
}
