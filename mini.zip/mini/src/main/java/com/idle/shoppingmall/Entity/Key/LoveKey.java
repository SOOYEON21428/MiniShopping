package com.idle.shoppingmall.Entity.Key;

import com.idle.shoppingmall.Entity.Love;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class LoveKey {

    private Long product_id;
    private Long created_who;

} // end class
