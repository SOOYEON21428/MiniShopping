package com.idle.shoppingmall.Controller.ControllerAPI.Manage;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class MProductDetailConroller {

}
