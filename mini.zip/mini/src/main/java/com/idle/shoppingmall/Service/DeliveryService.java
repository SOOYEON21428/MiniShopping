package com.idle.shoppingmall.Service;

public class DeliveryService {
}
