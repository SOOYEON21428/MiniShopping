const modify = document.querySelector(".modify-overlay");

function openModal() {
    modify.classList.add("open-modal");
}
function closeModal() {
    modify.classList.remove("open-modal");
}




