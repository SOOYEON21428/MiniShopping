const queryParam = new URLSearchParams(window.location.search);
